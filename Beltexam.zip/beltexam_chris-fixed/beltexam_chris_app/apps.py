from django.apps import AppConfig


class BeltexamChrisAppConfig(AppConfig):
    name = 'beltexam_chris_app'
