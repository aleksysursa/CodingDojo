
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('usercreated', views.create_user),
    path('login', views.login),
    path('dashboard', views.dashboard),
    path('a_wish', views.a_wish),
    path('addwish', views.add_wish),
    path('editwish/<int:wish_id>', views.edit_wish),
    path('process_edit/<int:wish_id>', views.process_edit),
    path('grant/<int:wish_id>', views.grant_wish),
    path('delete', views.delete),
    path('logout', views.logout)
]