from django.db import models
import re
import bcrypt
# Create your models here.

class UserManager(models.Manager):
    def reg_validator(self, post_data):
        errors = {}
        if len(post_data['first_name']) < 2:
            errors['first_name'] = "Looks like you left first name blank, please add your first name"
        if len(post_data['last_name']) < 2:
            errors['lname'] = "Last name cannot be left empty"
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(post_data['email']):
            errors['email'] = "A real email is required to enter the site."
        if len(post_data['password']) < 4:
            errors['password'] = "Your password needs to be more then 5 characters"
        
        return errors

class WishManager(models.Manager):
    def wish_validator(self, post_data):
        errors={}
        if len(post_data['wish']) < 3:
            errors['wish'] = "Your wish needs to be a tiny bit longer."
        if len(post_data['description']) < 3:
            errors['description'] = "Your description needs to be longer then ten characters"
        return errors



class User(models.Model):
    fname = models.CharField(max_length=255)
    lname = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    passw = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

class Wish(models.Model):
    user_id = models.ForeignKey(User, related_name = 'wish', on_delete= models.CASCADE)
    item = models.CharField(max_length=255, null=True)
    description = models.TextField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = WishManager()

class Granted(models.Model):
    user_object = models.ForeignKey(User, related_name = 'granted_user', on_delete= models.CASCADE)
    item_g = models.CharField(max_length=255, null=True)
    description_g = models.TextField(null=True)
    date_wished = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = WishManager()  