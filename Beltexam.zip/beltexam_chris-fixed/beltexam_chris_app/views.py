from django.shortcuts import render, redirect
from .models import User, Wish, Granted, UserManager, WishManager
from django.contrib import messages
import bcrypt

def index(request):
    return render(request, 'index.html')

def create_user(request):
    errors=User.objects.reg_validator(request.POST)
    if len(errors)>0:
        for error in errors.values():
            messages.error(request, error)
        return redirect('/')
    email = User.objects.filter(email=request.POST['email'])
    if email:
        messages.error(request, "Email already exists")
        return redirect('/')
    hashed_pw = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
    logged_user = User.objects.create(
        fname = request.POST['first_name'],
        lname = request.POST['last_name'],
        email = request.POST['email'],
        passw = hashed_pw
    )
    request.session['fname'] = logged_user.fname
    request.session['user_id'] = logged_user.id

    return redirect('/dashboard')

def login(request):
    login_user = User.objects.get(email=request.POST['email'])
    if bcrypt.checkpw(request.POST['password'].encode(), login_user.passw.encode()):
        request.session['user_name']= login_user.fname
        request.session['user_email']= login_user.email
        request.session['user_id'] = User.id
        request.session['user_id'] = login_user.id
        return redirect('/dashboard')
    
    return redirect('/dashboard')

def dashboard(request):
    context = {
        'user' : User.objects.get(id=request.session['user_id']),
        'wishes' : Wish.objects.all(),
        'granted' : Granted.objects.all()
        }
    return render (request, 'dashboard.html', context)

def add_wish(request):
    context = {
        'user' : User.objects.get(id=request.session['user_id']),
        'wishes' : Wish.objects.all()
    }
    return render(request, "addwish.html", context)

def a_wish(request):
    errors=Wish.objects.wish_validator(request.POST)
    if len(errors) > 0:
        for error in errors.values():
            messages.error(request, error)
        return redirect('/addwish')
    post = Wish.objects.create(
        user_id = User.objects.get(id=request.session['user_id']),
        item = request.POST['wish'],
        description = request.POST['description']
    )
    print(post.user_id, post.item, post.description)
    return redirect('/dashboard')

def edit_wish(request, wish_id):
    context = {
        'user' : User.objects.get(id=request.session['user_id']),
        'wishes' : Wish.objects.get(id=wish_id)
    }
    return render(request, "editwish.html", context)

def process_edit(request, wish_id):
    wish = Wish.objects.get(id=wish_id)
    print(wish.item, wish.description, "before")
    wish.item = request.POST['wishes']
    wish.description = request.POST['description']
    print(wish.item, wish.description, 'after')
    wish.save()
    return redirect('/dashboard')

def grant_wish(request, wish_id):
    wish = Wish.objects.get(id=wish_id)
    post = Granted.objects.create(
        user_object = User.objects.get(id=request.session['user_id']),
        item_g = wish.item,
        description_g = wish.description,
        date_wished = wish.created_at
    )
    wish.delete()
    print(post.item_g, post.user_object, post.description_g, post.date_wished)
    return redirect('/dashboard')

def delete(request):
    if request.method == 'POST':
        wish = Wish.objects.get(id=request.POST['wish_id'])
        wish.delete()
        return redirect('/dashboard')
    else:
        return redirect('/')

def logout(request):
    request.session.flush()
    return redirect('/')
